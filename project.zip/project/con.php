<?php
	$connection=mysqli_connect("localhost","root","password","Details");
	/*if($connection)
	{
	echo " Successfull";
	}
	else{
	echo "Error:".mysqli_error($connection);
	}*/
?>
